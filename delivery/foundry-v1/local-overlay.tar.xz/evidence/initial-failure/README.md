# Initial native trial — expected to remain FAILED

NET head c67d5f6c06d1419706aae72ac88efd0a0fa8ea62; game adapter
f6a7cf5e66e368bfb1ba069b22eecb2990f24be4; workflow run 36529093831.
The native adapter refused a valid numeric request before gameplay.
The original Session contains the runtime refusal and no fabricated result.
These records are not evidence of successful qualification. The corrected
source pin and successful five-campaign run are in ../native.
