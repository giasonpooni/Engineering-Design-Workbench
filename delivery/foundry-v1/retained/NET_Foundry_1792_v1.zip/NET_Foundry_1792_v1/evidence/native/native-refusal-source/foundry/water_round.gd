extends SceneTree
func _initialize() -> void:
	push_error("FOUNDRY qualification-only native refusal")
	quit(2)
